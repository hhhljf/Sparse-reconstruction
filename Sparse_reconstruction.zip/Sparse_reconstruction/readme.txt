1.This is a demo for the paper "Robust Precise Dynamic Point Reconstruction from Multi-view"

2.Run the demo scripts: Match_main for an example from our own dataset with 100 dynamic points and 27 frames.



